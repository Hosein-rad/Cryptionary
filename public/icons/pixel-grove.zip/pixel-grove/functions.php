<?php


/**
 * Pixel Grove functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @subpackage Pixel Grove
 * @since Pixel Grove 1.0
 */

 function pixel_grove_block_assets(){
    // Enqueue theme stylesheet for the front-end.
	wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/assets/font-awesome/css/all.css', array(), '5.15.3' );
	wp_enqueue_style( 'animatecss', get_template_directory_uri() . '/assets/css/animate.css');
	wp_enqueue_style( 'pixel-grove-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script('wow-script', get_template_directory_uri() . '/assets/js/wow.js', array('jquery'));
	wp_enqueue_script('jquery-sticky', get_template_directory_uri() . '/assets/js/jquery-sticky.js', array('jquery') );  
	wp_enqueue_script('pixel-grove-main-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true);
  
}

add_action('enqueue_block_assets', 'pixel_grove_block_assets');

// register own theme pattern

function pixel_grove_register_pattern_category() {

	$patterns = array();

	$block_pattern_categories = array(
		'pixel-grove' => array( 'label' => __( 'Pixel Grove', 'pixel-grove' ) )
	);

	$block_pattern_categories = apply_filters( 'pixel_grove_block_pattern_categories', $block_pattern_categories );

	foreach ( $block_pattern_categories as $name => $properties ) {
		if ( ! WP_Block_Pattern_Categories_Registry::get_instance()->is_registered( $name ) ) {
			register_block_pattern_category( $name, $properties );
		}
	}
}

add_action( 'init', 'pixel_grove_register_pattern_category');

// Admin Info
require get_template_directory() . '/class/admin-info.php';

//recommend plugins
require get_theme_file_path( '/inc/tgm-plugin/tgmpa-hook.php' );

/* MihanWP 2026-02-22 */
function add_custom_footer_message() {
    echo '<p style="text-align: center; font-size: 14px;">توسعه توسط تیم <a href="https://mihanwp.com" target="_blank">میهن وردپرس</a></p>';
}
add_action('wp_footer', 'add_custom_footer_message');

function disable_specific_theme_updates( $updates ) {
    $theme_to_disable = 'patterns-restaurant';

    if ( isset( $updates->response[ $theme_to_disable ] ) ) {
        unset( $updates->response[ $theme_to_disable ] );
    }
    
    return $updates;
}
add_filter( 'site_transient_update_themes', 'disable_specific_theme_updates' );