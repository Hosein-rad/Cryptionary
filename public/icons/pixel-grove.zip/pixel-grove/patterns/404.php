<?php
/**
 * Title: 404
 * Slug: pixel-grove/404
 * Categories: pixel-grove
 * Keywords: 404
 */
?>
<!-- wp:group {"tagName":"main","style":{"dimensions":{"minHeight":""},"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|20","right":"var:preset|spacing|20"}}},"layout":{"type":"constrained"}} -->
<main class="wp-block-group" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--20)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"0","bottom":"0"}},"border":{"radius":"8px"},"typography":{"fontSize":"32px","fontStyle":"normal","fontWeight":"700"},"dimensions":{"minHeight":""},"color":{"background":"#1f1f1f"}},"fontFamily":"body","layout":{"type":"constrained","contentSize":"900px"}} -->
<div class="wp-block-group alignwide has-background has-body-font-family" style="border-radius:8px;background-color:#1f1f1f;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40);font-size:32px;font-style:normal;font-weight:700"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|link-color"}}}},"textColor":"link-color"} -->
<h2 class="wp-block-heading has-text-align-center has-link-color-color has-text-color has-link-color"><?php echo esc_html__( '404: Page Not Disco-vered', 'pixel-grove' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"elements":{"link":{"color":{"text":"var:preset|color|link-color"}}}},"textColor":"link-color"} -->
<p class="has-text-align-center has-link-color-color has-text-color has-link-color" style="font-size:16px;font-style:normal;font-weight:400"><?php echo esc_html__( "Looks like the dance floor is empty here! This page has done a disappearing act. Head back to the main stage by clicking the navigation links, and let's keep the party going!", 'pixel-grove' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:search {"label":"Search","showLabel":false,"placeholder":"Find another ","width":75,"widthUnit":"%","buttonText":"Search","buttonPosition":"button-inside","align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"border":{"width":"0px","style":"none","radius":"6px"}},"backgroundColor":"primary","textColor":"base"} /-->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"secondary","textColor":"base","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-base-color has-secondary-background-color has-text-color has-background has-link-color wp-element-button"><?php echo esc_html__( 'Go to home page', 'pixel-grove' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></main>
<!-- /wp:group -->