<?php


/**
 * Venture Grove Plus functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @subpackage Venture Grove Plus
 * @since Venture Grove Plus 1.0
 */

 function venture_grove_plus_block_assets(){
    // Enqueue theme stylesheet for the front-end.
	wp_enqueue_style( 'venture-grove-plus-fontawesome', get_template_directory_uri() . '/assets/font-awesome/css/all.css', array(), '5.15.3' );
	wp_enqueue_style( 'venture-grove-plus-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script('venture-grove-plus-jquery-sticky', get_template_directory_uri() . '/assets/js/jquery-sticky.js', array('jquery') );  
	wp_enqueue_script('venture-grove-plus-main-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true);
  
}

add_action('enqueue_block_assets', 'venture_grove_plus_block_assets');

// register own theme pattern

function venture_grove_plus_register_pattern_category() {

	$patterns = array();

	$block_pattern_categories = array(
		'venture-grove-plus' => array( 'label' => __( 'Venture Grove Plus', 'venture-grove-plus' ) )
	);

	$block_pattern_categories = apply_filters( 'venture_grove_plus_block_pattern_categories', $block_pattern_categories );

	foreach ( $block_pattern_categories as $name => $properties ) {
		if ( ! WP_Block_Pattern_Categories_Registry::get_instance()->is_registered( $name ) ) {
			register_block_pattern_category( $name, $properties );
		}
	}
}

add_action( 'init', 'venture_grove_plus_register_pattern_category');