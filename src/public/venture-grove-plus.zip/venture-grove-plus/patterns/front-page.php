<?php
/**
 * Title: Front Page
 * Slug: venture-grove-plus/front-page
 * Categories: venture-grove-plus
 * Keywords: front-page
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"venture-grove-plus/banner"} /-->
<!-- wp:pattern {"slug":"venture-grove-plus/features"} /-->
<!-- wp:pattern {"slug":"venture-grove-plus/about"} /-->
<!-- wp:pattern {"slug":"venture-grove-plus/team"} /-->
<!-- wp:pattern {"slug":"venture-grove-plus/testimonials"} /-->
<!-- wp:pattern {"slug":"venture-grove-plus/articles"} /-->