<?php
/**
 * Title: Footer
 * Slug: venture-grove-plus/footer
 * Categories: footer,venture-grove
 * Keywords: footer
 * Block Types: core/template-part/footer
 */
?>
<!-- wp:group {"className":"wow animate__animated animate__fadeInUp","style":{"spacing":{"blockGap":"0","margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}},"color":{"background":"#1f2c09"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group wow animate__animated animate__fadeInUp has-background" style="background-color:#1f2c09;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"margin":{"top":"0","bottom":"0"}},"border":{"radius":"8px"}},"backgroundColor":"secondary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-secondary-background-color has-background" style="border-radius:8px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"typography":{"fontSize":"32px","fontStyle":"normal","fontWeight":"700"}}} -->
<h2 class="wp-block-heading" style="font-size:32px;font-style:normal;font-weight:700"><?php echo esc_html__( 'From Idea to Reality, Let’s Begin', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}}},"textColor":"contrast"} -->
<p class="has-contrast-color has-text-color has-link-color"><?php echo esc_html__( 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution', 'venture-grove-plus' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:buttons {"style":{"spacing":{"padding":{"top":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":{"left":"var:preset|spacing|10"}}},"layout":{"type":"flex","justifyContent":"right"}} -->
<div class="wp-block-buttons" style="margin-top:0;margin-bottom:0;padding-top:0"><!-- wp:button {"backgroundColor":"base-2","textColor":"contrast","className":"has-hover-effect","style":{"spacing":{"padding":{"left":"var:preset|spacing|30","right":"var:preset|spacing|30"}},"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}},"border":{"width":"1px"}},"borderColor":"secondary"} -->
<div class="wp-block-button has-hover-effect"><a class="wp-block-button__link has-contrast-color has-base-2-background-color has-text-color has-background has-link-color has-border-color has-secondary-border-color wp-element-button" style="border-width:1px;padding-right:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><?php echo esc_html__( 'Contact Us', 'venture-grove-plus' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"},"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:column {"width":"30%"} -->
<div class="wp-block-column" style="flex-basis:30%"><!-- wp:heading {"style":{"typography":{"fontSize":"21px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|base-2"}}},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|10"}}},"textColor":"base-2"} -->
<h2 class="wp-block-heading has-base-2-color has-text-color has-link-color" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--10);font-size:21px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Venture Grove Plus', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-6"}}},"typography":{"fontSize":"16px","lineHeight":"1.6"}},"textColor":"accent-6"} -->
<p class="has-accent-6-color has-text-color has-link-color" style="font-size:16px;line-height:1.6"><?php echo esc_html__( 'Pellentesque ut neque. Vestibulum facilisis, purus nec pulvinar iaculis, ligula mi congue nunc, vitae euismod ligula urna in dolor. In ut quam vitae odio lacinia tincidunt. Vestibulum dapibus nunc ac augue. Sed cursus turpis vitae tortor.', 'venture-grove-plus' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"typography":{"fontSize":"21px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|base-2"}}},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|10"}}},"textColor":"base-2"} -->
<h2 class="wp-block-heading has-base-2-color has-text-color has-link-color" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--10);font-size:21px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Quick Links', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"16px"}},"textColor":"base"} -->
<ul style="font-size:16px" class="wp-block-list has-base-color has-text-color has-link-color"><!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Home', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Services', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Pages', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'About Us', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Privacy Policy', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"typography":{"fontSize":"21px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|base-2"}}},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|10"}}},"textColor":"base-2"} -->
<h2 class="wp-block-heading has-base-2-color has-text-color has-link-color" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--10);font-size:21px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Support', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"16px"}},"textColor":"base"} -->
<ul style="font-size:16px" class="wp-block-list has-base-color has-text-color has-link-color"><!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Refund Policy', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Contact Us', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'News & Articles', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'About Us', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"6px"}}}} -->
<li style="margin-top:0;margin-bottom:6px"><?php echo esc_html__( 'Terms of Use', 'venture-grove-plus' ); ?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"typography":{"fontSize":"21px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|base-2"}}},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|10"}}},"textColor":"base-2"} -->
<h2 class="wp-block-heading has-base-2-color has-text-color has-link-color" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--10);font-size:21px;font-style:normal;font-weight:600"><?php echo esc_html__( 'get In Touch', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"blockGap":"8px"}},"textColor":"base","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group has-base-color has-text-color has-link-color"><!-- wp:image {"id":882,"width":"21px","height":"21px","scale":"contain","sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#405ff5","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/map.png" alt="" class="wp-image-882" style="object-fit:contain;width:21px;height:21px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"0","bottom":"0"}},"layout":{"selfStretch":"fill","flexSize":null}},"textColor":"base"} -->
<p class="has-base-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:16px"><?php echo esc_html__( 'Old City Street, USA, 123 New York 35035', 'venture-grove-plus' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"blockGap":"8px"}},"textColor":"base","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top","justifyContent":"left"}} -->
<div class="wp-block-group has-base-color has-text-color has-link-color"><!-- wp:image {"id":890,"width":"21px","height":"21px","scale":"contain","sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#405ff5","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/phone.png" alt="" class="wp-image-890" style="object-fit:contain;width:21px;height:21px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"textColor":"base"} -->
<p class="has-base-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:16px"><?php echo esc_html__( '+1-23-234-345', 'venture-grove-plus' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"blockGap":"8px"}},"textColor":"base","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group has-base-color has-text-color has-link-color"><!-- wp:image {"id":891,"width":"21px","height":"21px","scale":"contain","sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#405ff5","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/email.png" alt="" class="wp-image-891" style="object-fit:contain;width:21px;height:21px"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"textColor":"base"} -->
<p class="has-base-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:16px"><?php echo esc_html__( 'Example@example.com', 'venture-grove-plus' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"0","left":"var:preset|spacing|20","right":"var:preset|spacing|20"},"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"border":{"top":{"color":"#a3a3a387","width":"1px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="border-top-color:#a3a3a387;border-top-width:1px;margin-top:var(--wp--preset--spacing--20);margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:0;padding-left:var(--wp--preset--spacing--20)"><!-- wp:group {"style":{"border":{"top":{"width":"0px","style":"none"},"right":[],"bottom":[],"left":[]},"spacing":{"padding":{"top":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group" style="border-top-style:none;border-top-width:0px;padding-top:0"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base-2"}}}},"textColor":"base-2","fontSize":"small"} -->
<p class="has-base-2-color has-text-color has-link-color has-small-font-size"><?php echo esc_html__( 'Designed with ', 'venture-grove-plus' ); ?><a href="#" rel="nofollow"><?php echo esc_html__( 'WordPress', 'venture-grove-plus' ); ?> </a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base-2"}}}},"textColor":"base-2","fontSize":"small"} -->
<p class="has-base-2-color has-text-color has-link-color has-small-font-size"><?php echo esc_html__( 'Developed By ', 'venture-grove-plus' ); ?><a href="#"><?php echo esc_html__( 'Themegrove.com', 'venture-grove-plus' ); ?></a></p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"size":"has-small-icon-size","style":{"spacing":{"blockGap":{"left":"10px"}}},"layout":{"type":"flex","justifyContent":"right"}} -->
<ul class="wp-block-social-links has-small-icon-size"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"youtube"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"venture-grove-scrool-top"} -->
<p class="venture-grove-scrool-top"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->