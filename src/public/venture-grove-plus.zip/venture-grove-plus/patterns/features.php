<?php
/**
 * Title: Features
 * Slug: venture-grove-plus/features
 * Categories: venture-grove-plus
 * Keywords: features
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:group {"tagName":"main","metadata":{"name":"Our Features"},"className":"wow animate__animated animate__fadeInUp","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"backgroundColor":"accent","layout":{"type":"constrained"}} -->
<main class="wp-block-group wow animate__animated animate__fadeInUp has-accent-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"padding":{"top":"0"}}}} -->
<div class="wp-block-columns" style="padding-top:0"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"has-hover-effect","style":{"border":{"radius":"8px"},"spacing":{"padding":{"right":"var:preset|spacing|20","left":"var:preset|spacing|20","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-hover-effect has-base-2-background-color has-background" style="border-radius:8px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:image {"id":1472,"width":"46px","height":"auto","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/icon-2.png" alt="" class="wp-image-1472" style="width:46px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:18px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Local Knowledge', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"has-hover-effect","style":{"border":{"radius":"8px"},"spacing":{"padding":{"right":"var:preset|spacing|20","left":"var:preset|spacing|20","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-hover-effect has-base-2-background-color has-background" style="border-radius:8px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:image {"id":1473,"width":"48px","height":"auto","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/icon-3.png" alt="" class="wp-image-1473" style="width:48px;height:auto"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:18px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Pro Team', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":""} -->
<div class="wp-block-column"><!-- wp:group {"className":"has-hover-effect","style":{"border":{"radius":"8px"},"spacing":{"padding":{"right":"var:preset|spacing|20","left":"var:preset|spacing|20","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-hover-effect has-base-2-background-color has-background" style="border-radius:8px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:image {"id":1475,"width":"60px","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/icon-1.png" alt="" class="wp-image-1475" style="width:60px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:18px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Client Focus', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"has-hover-effect","style":{"border":{"radius":"8px"},"spacing":{"padding":{"right":"var:preset|spacing|20","left":"var:preset|spacing|20","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-hover-effect has-base-2-background-color has-background" style="border-radius:8px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:image {"id":1474,"width":"60px","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/images/icon-4.png" alt="" class="wp-image-1474" style="width:60px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:18px;font-style:normal;font-weight:600"><?php echo esc_html__( 'Smart Designs', 'venture-grove-plus' ); ?></h2>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></main>
<!-- /wp:group -->